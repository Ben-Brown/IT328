<!-- Jumbotron -->
<div class="jumbotron">
  <h1><?php echo "Welcome, ".$_SESSION['logged'];?></h1>
  <p>This is the Aviation Vocabulary Builder website. </p>
  <p>
    <a class="btn btn-success btn-lg" role="button">
      Get started
    </a>
  </p>
</div> <!-- End jumbotron -->