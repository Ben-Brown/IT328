<!-- Jumbotron -->
<div class="jumbotron">
  <h1>Buy my stuff!</h1>
  <p>This is my site. It's awesome. Check
  out my cool products. You won't regret it.</p>
  <p>
    <a class="btn btn-success btn-lg" role="button">
      Learn more
    </a>
  </p>
</div> <!-- End jumbotron -->

<!-- Three column layout -->
<div class="row">
  
  <!-- Column 1 -->
  <div class="col-md-4">
    <h2>Trinkets</h2>
    <p>Start with this basic HTML template, or modify these examples. We hope you'll customize our templates and examples, adapting them to suit your needs.</p>
    <p><a class="btn btn-default" role="button">Details</a></p>
  </div>

  <!-- Column 2 -->
  <div class="col-md-4">
    <h2>Trinkets</h2>
    <p>Start with this basic HTML template, or modify these examples. We hope you'll customize our templates and examples, adapting them to suit your needs.</p>
    <p><a class="btn btn-default" role="button">Details</a></p>
  </div>
  
  <!-- Column 3 -->
  <div class="col-md-4">
    <h2>Trinkets</h2>
    <p>Start with this basic HTML template, or modify these examples. We hope you'll customize our templates and examples, adapting them to suit your needs.</p>
    <p><a class="btn btn-default" role="button">Details</a></p>
  </div>
  
</div> <!-- End three column layout -->