<?php //Connect to the database
    $username = "logan_aviation";
    $password = "Storm_Eagles";
    $hostname = "localhost";
?>