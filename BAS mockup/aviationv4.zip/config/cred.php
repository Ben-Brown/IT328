<?php //Connect to the database
	$adminName = "gcomollo@greenriver.edu";
	$adminPwd = "Password01";
?>